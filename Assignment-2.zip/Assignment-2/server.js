var mongoose = require('mongoose'),
    assert = require('assert');
	
	
var Dishes = require('./models/dishesSchema');
var Promotions = require('./models/promoSchema');
var url = 'mongodb://localhost:27017/sample';

mongoose.connect(url);
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error'));
db.once('open', function(){
	console.log("Connected correctly to server");
	
	Dishes.create({
		name:'Pizza',
		image: 'images/uthapizza.png',
		category: 'mains',
		label: 'mild',
		price: '$120.99',
		description: 'A unique ....',
		comments: [
		{
			rating : 3,
			comment: 'Good',
			author: 'Gowtham'
		}
		]
	},
       function(err,dish){
		   if(err) throw err;
		   console.log('Dish created');
		   console.log(dish);
		   
		  var id = dish._id;
		   
		   
			   Dishes.findByIdAndUpdate(id, {
				  id.price.toFixed(2)
				   
				   
		   },{
			   new: true
		   })
		   .exec(function(err,dish){
			   if(err) throw err;
			   console.log('Updated Dish');
			   console.log(dish);
			  
		   
			   db.collection('dishes').drop(function() {
				   db.close();
			   });
			   
		   });
		   
		   
	 

	   });

	
	});
