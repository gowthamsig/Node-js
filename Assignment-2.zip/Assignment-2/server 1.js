var mongoose = require('mongoose'),
    assert = require('assert');
	
	
var Dishes = require('./models/dishesSchema');
var Promotions = require('./models/promotionSchema');
var url = 'mongodb://localhost:27017/sample';

mongoose.connect(url);
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error'));
db.once('open', function(){
	console.log("Connected correctly to server");
	
	Promotions.create({
		name:'Weekend Grand Dinner Buffet',
		image: 'images/buffet.png',
		label: 'New',
		price: '$120.99',
		description: 'Featuring ....',
		
	},
       function(err,promotion){
		   if(err) throw err;
		   console.log('Promotion created');
		   console.log(promotion);
		   
		   var id = promotion._id;
		   var record = Promotions.findById(promotion._id);
		   var price_update = record.price;
		   	console.log('price_update');	   
		   
			   Promotions.findByIdAndUpdate(id, {
				 $set:{
					 price : '$4.99'
					 
				 }
				   
				   
		   },{
			   new: true
		   })
		   .exec(function(err,promotion){
			   if(err) throw err;
			   console.log('Updated Dish');
			   console.log(promotion);
			  
		   
			   db.collection('promotions').drop(function() {
				   db.close();
			   });
			   
		   });
		   
		   
	 

	   });

	
	});
