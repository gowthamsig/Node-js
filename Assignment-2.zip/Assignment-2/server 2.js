var mongoose = require('mongoose'),
    assert = require('assert');
	
	
var Dishes = require('./models/dishesSchema');
var Promotions = require('./models/promotionSchema');
var Leaders = require('./models/leadershipSchema');
var url = 'mongodb://localhost:27017/sample';

mongoose.connect(url);
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error'));
db.once('open', function(){
	console.log("Connected correctly to server");
	
	Leaders.create({
		name:'Peter Pan',
		image: 'images/alberto.png',
		designation: 'Chief Epicurious Officer',
		abbr: 'CEO',
		description: 'Our CEO, Peter, . . . ....',
		
	},
       function(err,leader){
		   if(err) throw err;
		   console.log('Leader created');
		   console.log(leader);
		   
		   var id = leader._id;
		  // var record = Promotions.findById(promotion._id);
		   //var price_update = record.price;
		   	//console.log('price_update');	   
		   
			   Leaders.findByIdAndUpdate(id, {
				 $set:{
					 abbr : 'CEEO'
					 
				 }
				   
				   
		   },{
			   new: true
		   })
		   .exec(function(err,leader){
			   if(err) throw err;
			   console.log('Updated Dish');
			   console.log(leader);
			  
		   
			   db.collection('leaders').drop(function() {
				   db.close();
			   });
			   
		   });
		   
		   
	 

	   });

	
	});
