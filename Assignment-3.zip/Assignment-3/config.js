module.exports={
	'secret-key':'12345-67890-09876-5432',
	'mongourl':'mongodb://localhost:27017/sample'
}