var express = require('express');
var bodyParser = require('body-parser');

	
var promorouter = express.Router();

promorouter.use(bodyParser.json());

promorouter.route('/')

.all(function(req,res,next) {
	res.writeHead(200, { 'content-type': 'text/plain' });
	next();
})

.get(function(req,res,next){
	res.end("will send all the promotions to you");
})

.post(function(req,res,next){
	
	res.end('Will add this promotion: ' + req.body.name + ' with details ' + req.body.description);
})

.delete(function(req,res,next){
	res.end('Deleting all the promotions');
});

promorouter.route('/:promotionId')

.all(function(req,res,next){
	res.writeHead(200, { 'content-type': 'text/plain' });
	next();
})

.get(function(req,res,next){
	res.end('Will send the details of promotion ' + req.params.promotionId + ' to you');
})

.put(function(req,res,next){
	res.write('Updating the promotion ' + req.params.promotionId + '\n');
	res.end('Will update the promotion ' + req.body.name + ' with details ' + req.body.description);
})

.delete(function(req,res,next){
	res.end('Deleting the promotion ' + req.params.promotionId);
});	
	

module.exports = promorouter;