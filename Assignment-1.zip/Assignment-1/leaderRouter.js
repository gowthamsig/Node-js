var express = require('express');
var bodyParser = require('body-parser');

	
var leaderrouter = express.Router();

leaderrouter.use(bodyParser.json());

leaderrouter.route('/')

.all(function(req,res,next) {
	res.writeHead(200, { 'content-type': 'text/plain' });
	next();
})

.get(function(req,res,next){
	res.end("will send all the leader to you");
})

.post(function(req,res,next){
	
	res.end('Will add this leader: ' + req.body.name + ' with details ' + req.body.description);
})

.delete(function(req,res,next){
	res.end('Deleting all the leaders');
});

leaderrouter.route('/:leaderId')

.all(function(req,res,next){
	res.writeHead(200, { 'content-type': 'text/plain' });
	next();
})

.get(function(req,res,next){
	res.end('Will send the details of leader ' + req.params.leaderId + ' to you');
})

.put(function(req,res,next){
	res.write('Updating the leader ' + req.params.leaderId + '\n');
	res.end('Will update the leader ' + req.body.name + ' with details ' + req.body.description);
})

.delete(function(req,res,next){
	res.end('Deleting the leader ' + req.params.leaderId);
});	
	

module.exports = leaderrouter;