module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl' : 'mongodb://localhost:27017/sample',
	'facebook': {
        clientID: '2116740781885461',
        clientSecret: 'a319184377b4ccccade29d2c983c3bbd',
        callbackURL: 'https://localhost:443/users/facebook/callback'
    }
}